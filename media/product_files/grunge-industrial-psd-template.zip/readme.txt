                                          ===========================-: THANK YOU :-===========================

★ Thank you for purchasing Grunge Industrial PDS Template. Below is some information about the template. If you have any questions or comments contact me at steve@steve-shead.com.

                                         ===========================-: INFORMATION :-===========================

★ I have left all the layers intact so that you can change the look and feel, colors and text with ease. Remember to take note of the layers properties before you change it, just in case, and always keep a back up of the original file. The template is infinitely editable - none of the shapes have been raterized, and I've used overlays to create deeper effects.

                                          ===========================-: THANKS AGAIN :-===========================

★ Thanks again for purchasing this PSD Photoshop Template. If you have any questions feel free to email me at steve@steve-shead.com. 